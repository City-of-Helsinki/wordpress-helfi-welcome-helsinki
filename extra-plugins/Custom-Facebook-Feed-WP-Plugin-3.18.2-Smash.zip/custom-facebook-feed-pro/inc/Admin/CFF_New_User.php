<?php
/**
 * CFF_New_User.
 *
 * @since 2.18
 */

namespace CustomFacebookFeed\Admin;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CFF_New_User {
	/**
	 * Not used in Pro Version
	 *
	 * @return array
	 */
	public function get() {
	    return array();
	}
}
